import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { TokenService } from '../../../services/token.service';
import { Subscription, filter } from 'rxjs';

@Component({
  selector: 'app-navbar',
  standalone: false, 
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit, OnDestroy {
  userEmail: string = '';
  isAdmin: boolean = false;
  private routerSubscription?: Subscription;

  constructor(
    private authService: AuthService,
    private tokenService: TokenService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Load user info initially
    this.updateUserInfo();

    // Subscribe to router events to update user info on navigation
    // This ensures the navbar updates after login/logout
    this.routerSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        this.updateUserInfo();
      });
  }

  ngOnDestroy(): void {
    // Clean up subscription to prevent memory leaks
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }

  private updateUserInfo(): void {
    // Re-fetch user email and admin status from token
    this.userEmail = this.tokenService.getUserEmail() || 'User';
    this.isAdmin = this.tokenService.isAdmin();
  }

  logout(): void {
    if (confirm('Are you sure you want to logout?')) {
      this.authService.logout();
      // Clear user info immediately
      this.userEmail = '';
      this.isAdmin = false;
    }
  }
}