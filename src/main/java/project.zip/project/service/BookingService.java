package project.service;

import org.springframework.http.ResponseEntity;
import project.entity.Booking;

import java.util.List;
import java.util.Map;

public interface BookingService {

    // Create a new booking
    ResponseEntity<String> createBooking(Map<String, String> requestMap);

    // Get all bookings for current logged-in user
    ResponseEntity<List<Booking>> getMyBookings();

    // Get all bookings (admin only)
    ResponseEntity<List<Booking>> getAllBookings();

    // Get booking by ID
    ResponseEntity<Booking> getBookingById(Integer id);

    // Cancel booking
    ResponseEntity<String> cancelBooking(Integer id);

    // Get bookings for a specific train (admin only)
    ResponseEntity<List<Booking>> getBookingsByTrainId(Integer trainId);
}